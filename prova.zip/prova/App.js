import { Text, SafeAreaView, StyleSheet, Button, Alert, TextInput, Image } from 'react-native';

// You can import supported modules from npm
import { Card } from 'react-native-paper';

// or any files within the Snack
import AssetExample from './components/misticSageTree';

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.paragraph}>
      <Text style={{color: 'pink', fontStyle: ''}}>
       INFO 4
       </Text>
      </Text>
      <Text style={styles.paragraph}>
      <text style={{color: 'PURPLE', fontSize: 10}}>
      INFO 5
      </text>
      </Text>
      <TextInput style={{fontSize: 12, textAlign: 'center', borderWidth: 1}}
      placeholder='Curso'
      />
      <TextInput style={{textAlign: 'center', borderWidth: 3}}
      keyboardType='numeric'
       placeholder='Período'
      />
      <Image
        style={styles.logo}
        source={{
          uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRCZj_HieT5HVgylBPNokBkBVpT9Zk0TQGB4w&s',
        }}
      />
      <Button
      title='UAU!'
       onPress={() => Alert.alert('UAU!')}
      />
      <Card>
        <AssetExample />
      </Card>
      <TextInput style={styles.input}
      placeholder='FIM'
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'green',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 26,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  input: {
    textAlign: 'center',
    fontSize: 20,
    color: 'red', 
    fontWeight: 'bold',
  },
});
